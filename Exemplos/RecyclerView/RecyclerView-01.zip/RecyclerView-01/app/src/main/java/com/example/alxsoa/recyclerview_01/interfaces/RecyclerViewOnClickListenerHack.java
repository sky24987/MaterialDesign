package com.example.alxsoa.recyclerview_01.interfaces;

import android.view.View;

/**
 * Created by viniciusthiengo on 4/5/15.
 */
public interface RecyclerViewOnClickListenerHack {
    public void onClickListener(View view, int position);
}
